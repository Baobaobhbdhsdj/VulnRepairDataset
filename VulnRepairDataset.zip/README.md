# VulnRepairDataset

This repository contains the datasets used in our paper:  
**"Exploring Prompt Patterns for Effective Vulnerability Repair in Real-World Code by Large Language Models"**

## 📁 Dataset Structure

The dataset is organized based on the number of lines of code (LOC) in each C/C++ file:

- `small/` (0–40 LOC): 2749 simple and short vulnerable code snippets
- `medium/` (41–80 LOC): 1286 mid-sized code examples with moderate complexity
- `large/` (>80 LOC): 1791 large and complex vulnerable code files

All files contain known vulnerabilities and were used in our experiments to evaluate the performance of different LLM-based repair strategies across various code complexities.

## 📖 Usage

You can use this dataset to:

- Reproduce the experiments from our research
- Test LLM-based code repair under varying levels of code complexity
- Analyze how vulnerability repair performance scales with code size

Each file can be paired with prompt templates or CFGs depending on your experimental design.

---

*This dataset is provided for academic and research purposes only.*
