#include <stdio.h>
int main(int argc, char *argv[])
{
	int a = 1;
	scanf("%d", &a);
	switch(a)
	{
	    case 1:
	    {
	        printf("Washington");
	        break;
	    }   
	    case 2:
	    {
	        printf("Adams");
	        break;
	    }   
	    case 3:
	    {
	        printf("Jefferson");
	        break;
	    }   
	    case 4:
	    {
	        printf("Madison");
	        break;
	    }   
	    case 5:
	    {
	        printf("Monroe");
	        break;
	    }   
	    case 6:
	    {
	        printf("Adams");
	        break;
	    }   
	    case 7:
	    {
	        printf("Jackson");
	        break;
	    }   
	    case 8:
	    {
	        printf("Van Buren");
	        break;
	    }   
	    case 9:
	    {
	        printf("Henry Harrison");
	        break;
	    }   
	    case 10:
	    {
	        printf("Tyler");
	        break;
	    }   
	    case 11:
	    {
	        printf("Polk");
	        break;
	    }   
	    case 12:
	    {
	        printf("Taylor");
	        break;
	    }   
	    case 13:
	    {
	        printf("Fillmore");
	        break;
	    }   
	    case 14:
	    {
	        printf("Pierce");
	        break;
	    }   
	    case 15:
	    {
	        printf("Buchanan");
	        break;
	    }   
	    case 16:
	    {
	        printf("Lincoln");
	        break;
	    }   
	    case 17:
	    {
	        printf("Johnson");
	        break;
	    }   
	    case 18:
	    {
	        printf("Grant");
	        break;
	    }   
	    case 19:
	    {
	        printf("Hayes");
	        break;
	    }   
	    case 20:
	    {
	        printf("Garfield");
	        break;
	    }   
	    case 21:
	    {
	        printf("Arthur");
	        break;
	    }   
	    case 22:
	    {
	        printf("Cleveland");
	        break;
	    }   
	    case 23:
	    {
	        printf("Harrison");
	        break;
	    }   
	    case 24:
	    {
	        printf("Cleveland");
	        break;
	    }   
	    case 25:
	    {
	        printf("McKinley");
	        break;
	    }   
	    case 26:
	    {
	        printf("Roosevelt");
	        break;
	    }   
	    case 27:
	    {
	        printf("Taft");
	        break;
	    }   
	    case 28:
	    {
	        printf("Wilson");
	        break;
	    }   
	    case 29:
	    {
	        printf("Harding");
	        break;
	    }   
	    case 30:
	    {
	        printf("Coolidge");
	        break;
	    }   
	    case 31:
	    {
	        printf("Hoover");
	        break;
	    }   
	    case 32:
	    {
	        printf("Roosevelt");
	        break;
	    }   
	    case 33:
	    {
	        printf("Truman");
	        break;
	    }   
	    case 34:
	    {
	        printf("Eisenhower");
	        break;
	    }   
	    case 35:
	    {
	        printf("Kennedy");
	        break;
	    }   
	    case 36:
	    {
	        printf("Johnson");
	        break;
	    }   
	    case 37:
	    {
	        printf("Nixon");
	        break;
	    }   
	    case 38:
	    {
	        printf("Ford");
	        break;
	    }   
	    case 39:
	    {
	        printf("Carter");
	        break;
	    }   
	    case 40:
	    {
	        printf("Reagan");
	        break;
	    }  
	}
	return 0;
}
